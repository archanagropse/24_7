                <footer class="footer ptb-20">

                  <div class="row">

                    <div class="col-md-12 text-center">

                      <div class="copy_right">

                        <p>

                          2018 ©  All Right Reserved by 24/7 Care. Design By

                          <a href="#">TechGropse</a>

                        </p>

                      </div>

                      <a id="back-to-top" href="#">

                        <i class="fa fa-arrow-up"></i>

                      </a>

                    </div>

                  </div>

                </footer>

          </div>

            <script src="<?php echo base_url('assets/js/jquery.min.js'); ?>"></script>

            <script src="<?php echo base_url('assets/js/popper.min.js'); ?>"></script>

            <script src="<?php echo base_url('assets/js/bootstrap.min.js'); ?>"></script>

            <script src="<?php echo base_url('assets/js/jquery.mCustomScrollbar.concat.min.js'); ?>"></script>

            <script src="<?php echo base_url('assets/js/Chart.bundle.js'); ?>"></script>

            <script src="<?php echo base_url('assets/js/utils.js'); ?>"></script>

            <script src="<?php echo base_url('assets/js/chart.js'); ?>"></script>

            <script src="<?php echo base_url('assets/js/jquery.dataTables.min.js'); ?>"></script>

             <script src="<?php echo base_url('assets/js/dataTables.bootstrap4.min.js'); ?>"></script>

             <script src="<?php echo base_url('assets/js/chart.js'); ?>"></script>

            <script src="<?php echo base_url('assets/js/jquery.dcjqaccordion.2.7.js'); ?>"></script>

            <script src="<?php echo base_url('assets/js/moment.min.js'); ?>"></script>
            <script src="<?php echo base_url('assets/js/fullcalendar.js'); ?>"></script>
            <script src="<?php echo base_url('assets/js/calendar-list-init.js'); ?>"></script>
            <script src="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.9/summernote.js"></script>
 
            <script src="<?php echo base_url('assets/js/custom.js'); ?>"></script>

	</body>

</html>